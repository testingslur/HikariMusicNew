from ubot import *


@PY.BOT("status")
async def _(client, message):
    await profile_command(client, message)


@PY.CALLBACK("start_profile")
async def _(client, message):
    await ewdsfgj(client, message)
